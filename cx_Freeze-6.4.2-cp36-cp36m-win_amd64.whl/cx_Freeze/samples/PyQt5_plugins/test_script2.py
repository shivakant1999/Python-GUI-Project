print("bye")
